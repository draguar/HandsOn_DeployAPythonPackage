# Hands On: Deploy a python package
Don't worry about the code, it's just an old simulation project that I deploye in the context of the hands-on based on Sergio Peignier's teaching, available at https://sergiopeignier.github.io/tutorial_python_packaging.html

The hands-on content can be found in [the project's wiki](https://github.com/draguar/HandsOn_DeployAPythonPackage/wiki)
